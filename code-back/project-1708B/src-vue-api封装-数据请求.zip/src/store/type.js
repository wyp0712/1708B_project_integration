export const INIT_BOOK_DATA = 'initBookData';
export const SHOW_DIALOG = 'show_dialog'