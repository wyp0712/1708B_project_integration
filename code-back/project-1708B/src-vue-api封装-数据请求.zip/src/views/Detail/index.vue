<template>

</template>

<script>
export default {
  created() {
    console.log(this.$route, '详情页面')
  },
}
</script>

<style>

</style>