import React from 'react'
import {Switch,Route, Redirect} from 'react-router-dom'

const Routerview = (props)=> {
    const comarr = props.routes.filter(val=>val.component)
    const arr = props.routes.filter(val=>val.redirect)
    return(
        <Switch>
            {
                comarr.map((item,index)=>{
                    return <Route key={index} path={item.path} component={item.component}></Route>
                })
            }
           

            {
                arr.map((item,index)=>{
                    return <Redirect to={item.redirect} key={index}></Redirect>
                })
            }

        </Switch>
    ) 
}

export default Routerview