
//一级
import A from '../views/a'
import B from '../views/b'
import C from '../views/c'


const route = [
    {
        path:'/',
        redirect:'/a'
    }
    ,
    {
        path:'/a',
        component:A
    },
    {
        path:'/b',
        component:B
    },{
        path:'/c',
        component:C
    }
]

export default route