import React, { Component } from 'react'

class C extends Component{
    render(){
        return(
            <div>
                我是C
            </div>
        )
    }
}
export default C