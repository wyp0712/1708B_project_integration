import React, { Component } from 'react'

class B extends Component{
    render(){
        return(
            <div>
                我是B
            </div>
        )
    }
}
export default B