import React, { Component } from 'react'

class A extends Component{
    render(){
        return(
            <div>
                我是A
            </div>
        )
    }
}
export default A