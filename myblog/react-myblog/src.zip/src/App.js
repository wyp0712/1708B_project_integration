import React, { Component } from 'react';
import Routerview from './router/index'
import {BrowserRouter} from 'react-router-dom'
import config from './router/config'

class App extends Component{
  render(){
    return(
      <BrowserRouter>
        <Routerview routes={config}></Routerview>
      </BrowserRouter>
    )
  }
}

export default App;
