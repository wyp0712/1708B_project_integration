import React, { Component } from 'react'

export default class componentName extends Component {
  render() {
    return (
      <div>
        添加页面
      </div>
    )
  }
}
