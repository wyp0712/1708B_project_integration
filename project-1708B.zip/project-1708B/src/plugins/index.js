import Vue from 'vue'
import Vant from 'vant'  //js文件里无法使用挂载到vue全局的函数，只能手动引进来
import 'vant/lib/index.css';
Vue.use(Vant);
