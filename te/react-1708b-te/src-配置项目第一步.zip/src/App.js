import React from 'react';
import { BrowserRouter, HashRouter, Route, Switch, Redirect, NavLink } from 'react-router-dom'

import RouterView from '@/router/index'
import config from '@/router/config'

function App() {
  return (
    <div className="App">
      <BrowserRouter>
       <div>



       </div>
        <RouterView routes={config} /> 
      </BrowserRouter>
     </div>
  );
}

export default App;
