<template>
  
</template>

<script>
import { testPostList } from '@/api/api.js';
import axios from 'axios';
export default {
  name: 'home',
  components: {
  },
  created() {

    // testPostList({
    //   user:'devin'
    // }).then(res => {
    //   console.log(res, 'res')
    // })

  },
}
</script>

<style>

</style>