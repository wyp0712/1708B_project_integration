import { combineReducers } from 'redux'
import todo from './todo'
import cart from './cart'

export default combineReducers({
  todo,
})